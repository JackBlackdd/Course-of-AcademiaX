npm init
npm install express --save
