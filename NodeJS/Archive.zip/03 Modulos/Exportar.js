const { sumar, numero } = require('../sumar');

const suma = sumar(numero, 2);
console.log(suma);