const _ = require("lodash");

const nums = _.range(1, 9);
console.log(nums);