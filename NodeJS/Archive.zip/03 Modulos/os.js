const os = require('os');

console.log(os.arch());
console.log(os.cpus());
console.log(os.freemem());
console.log(os.version());
