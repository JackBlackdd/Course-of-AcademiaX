// Object();

const lista = new Array();
// console.log(Object.prototype);

class SuperArray extends Array {

}
console.log(SuperArray.prototype);
