console.log('Hello World');
// console.log(5);
console.log([1,2,3]); // estos son numeros 
console.log({ key: 'value'});

/*
Este
es 
un 
comentario
multilínea
*/