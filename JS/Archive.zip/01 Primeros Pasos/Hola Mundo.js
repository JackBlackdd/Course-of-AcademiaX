console.log('Hello World');
console.log([1,2,3]);
console.log({ key: 'value'});