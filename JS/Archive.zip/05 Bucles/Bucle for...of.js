let lista = [1, 2, 3, 5, 8];

for (let elemento of lista) {
    console.log(elemento + 4);
}