
let i = 0;
do {
    console.log('una vez');
    i++;
} while (i < 4);