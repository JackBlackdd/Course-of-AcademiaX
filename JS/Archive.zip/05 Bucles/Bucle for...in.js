let traductor = {
    bucle: 'loop',
    lista: 'array',
    declaración: 'declaration',
    objecto: 'object'
};

for (let etiqueta in traductor) {
    console.log(etiqueta + ' en inglés es ' + traductor[etiqueta]);
}

