var a = 10;
let b = 20, c = 30;
a = 40;
d = 50;
const e = 60;
// e = 70;
console.log(a, b, c, d, e);