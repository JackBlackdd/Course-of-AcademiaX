let verdadero = true;
let falso = false;
// console.log(verdadero, falso);

let hogar = 'Seattle';
let ciudad = 'New York';

console.log(hogar === ciudad);