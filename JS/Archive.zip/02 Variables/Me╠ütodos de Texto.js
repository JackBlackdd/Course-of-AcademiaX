let texto = "Pink Floyd";
console.log(texto.length);
console.log(texto.toUpperCase());
console.log(texto.toLowerCase());
console.log(texto.includes('Floyd'));