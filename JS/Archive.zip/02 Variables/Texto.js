let libro = 'Harry\n\
Potter\'s\n\Castle';
let segundoLibro = "Pragmatic 'Programmer'";

console.log(libro, segundoLibro);