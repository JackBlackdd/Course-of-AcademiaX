let numero = 5;
let decimales = 5.234265435345938734587987345983745;
let negativos = -10;
let infinito = Infinity;

// console.log(numero);
// console.log(decimales);
// console.log(negativos);
// console.log(infinito);
// console.log(-infinito);
// console.log(NaN);

// console.log(Math.PI)
// console.log(Math.round(decimales));
console.log(Math.random());

