let listaVacia = [];
let listaDeNumeros = [1,2,3,4,5];
let listaDeTextos = ['Lunes', 'Martes', 'Miércoles'];
let listaRandom = [1, 'Lunes', true, {}, [false]];

// console.log(listaDeTextos);
// console.log(listaRandom);
// console.log(listaRandom[0]);
// console.log(listaRandom[1]);
// console.log(listaRandom[2]);
// console.log(listaRandom[3]);
// console.log(listaRandom[4]);
console.log(listaRandom[4][0]);