console.log(sumar(1,2));

let sumar2 = function(a,b) {
    return a + b;
}
console.log(sumar2(1,2));

function sumar(a,b) {
    return a + b;
}


