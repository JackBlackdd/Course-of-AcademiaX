// console.log(3);
// let texto = 'hola';
// console.log(texto.toUpperCase());

let perro = {
    nombre: 'Firulais',
    ladra: function() {
        console.log('Woof!');
    }
};

perro.ladra();