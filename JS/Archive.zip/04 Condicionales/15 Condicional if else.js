let admin = 'Xavier';
let usuario = admin;

if (usuario === 'Pedro') {
    console.log('Autorizado!');
} else if (usuario === 'Emilia') {
    console.log('Autorizado con privilegios!');
} else {
    console.log('NO Autorizado!');
}