let usuario = 'Emilia';

switch (usuario) {
    case 'Pedro':
        console.log('ADMINISTRADOR');
    case 'Emilia':
        console.log('Autorizado');
        break;
    default:
        console.log('No Autorizado');
}