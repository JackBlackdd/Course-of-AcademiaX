// console.log(3 + 4);
// console.log(3 - 4);
// console.log(3 * 4);
// console.log(12 / 4);
// console.log(12 % 7);
// par vs impar
// console.log(12 % 2); 
// console.log(11 % 2); 

let a = 10;
a = a + 1;
a += 5;
a++;
console.log(a);
a = a - 1;
a -= 5;
a--;
console.log(++a);
console.log(a);

