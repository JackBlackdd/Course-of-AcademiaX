let diez = 10;
let diez2 = '10';
console.log(diez != diez2);
console.log(diez !== diez2);