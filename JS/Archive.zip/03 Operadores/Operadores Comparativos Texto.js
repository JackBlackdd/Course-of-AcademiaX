let a = 'a';
let b = 'b';

// console.log(a > b);
// console.log(a < b);

let A = 'A';

// console.log(A < a);
// console.log(A > a);

// console.log('z' > 'A');
console.log('z'.toUpperCase() > 'A'.toUpperCase());



